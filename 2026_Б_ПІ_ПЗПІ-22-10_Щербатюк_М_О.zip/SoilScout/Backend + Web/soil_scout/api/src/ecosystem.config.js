module.exports = {
    apps : [{
        name: 'my-backend',
        script: 'index.js',
        instances: "8",
        autorestart: true,
        watch: false,
        max_memory_restart: '1G',
        env: {
            NODE_ENV: 'development',
            PORT: 5001
        },
        env_production: {
            NODE_ENV: 'production',
            PORT: 5001
        },
        exec_mode: 'cluster',
        increment_var: 'PORT'
    }]
};